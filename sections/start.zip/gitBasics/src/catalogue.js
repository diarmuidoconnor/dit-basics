const Product = require("./product");
const _ = require("lodash");

function Catalogue() {
  this.products = [];

  this.addProduct = function(product) {
    this.products.push(product);
  };
  this.findProductByName = function(name) {
    const match = this.products.find(function(product) {
      return name.toUpperCase() === product.name.toUpperCase();
    });
    return match == undefined ? null : match;
  };

  this.removeProductByName = function(name) {
    const criteria = function(element) {
      return element.name === name;
    };
    const index = _.findIndex(this.products, criteria);
    if (index !== -1) {
      _.remove(this.products, criteria);
    }
    return index;
  };
}

module.exports = Catalogue;
