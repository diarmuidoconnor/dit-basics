const Catalogue = require('../src/catalogue' );
const Product = require('../src/product' );

const cat = new Catalogue() ;
// Setup
cat.addProduct(new Product("Product 1", 100, 10.00, 10  ) );
cat.addProduct(new Product("Product 2", 100, 10.00, 10 ) );
cat.addProduct(new Product("Product 3", 100, 10.00, 10 ) );

// Test findProductByName
let match = cat.findProductByName('Product X' );
if (match !== null) {
    console.log("find by name - Failed when invalid name")
} else {
    console.log("find by name - passed  when invalid name")
}

match = cat.findProductByName("Product 2" ) ;
if (match !== null) {
    console.log("find by name - passed when valid name")
} else {
    console.log("find by name - failed  when valid name")
}
